﻿(function($, core, shell, undefined) {

shell.driver({
    name: 'userjs',
    create: function() {
        // To insert code here.
    }
});

})(jQuery, nethelp, nethelpshell);